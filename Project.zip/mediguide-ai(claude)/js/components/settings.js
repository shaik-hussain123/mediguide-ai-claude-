/** @file Settings, accessibility prefs (FR-10.1), API key management (FR-9), right to delete (§8.4). */
import { $, openModal, showToast } from '../utils/helpers.js';
import * as store from '../utils/storage.js';
import * as audit from '../utils/audit.js';
import * as gemini from '../services/gemini.js';
import { KEYS, GEMINI, APP } from '../config.js';

const DEFAULTS = { elderly: false, contrast: false, font: 'normal', saveHistory: true };
export const getPrefs = () => ({ ...DEFAULTS, ...store.get(KEYS.prefs, {}) });
const setPrefs = (patch) => { const p = { ...getPrefs(), ...patch }; store.set(KEYS.prefs, p); applyPrefs(p); return p; };

export function applyPrefs(p = getPrefs()) {
  document.documentElement.classList.toggle('elderly', p.elderly);
  document.documentElement.classList.toggle('high-contrast', p.contrast);
  document.documentElement.dataset.font = p.font;
  $('#elderlyToggle').setAttribute('aria-pressed', String(p.elderly));
  $('#elderlyToggle').classList.toggle('active', p.elderly);
  $('#settingsElderlyMode').checked = p.elderly;
  $('#settingsHighContrast').checked = p.contrast;
  $('#settingsFontSize').value = p.font;
  $('#settingsSaveHistory').checked = p.saveHistory;
}

function renderKeyStatus(active) {
  $('#apiStatus').className = `api-status${active ? ' active' : ''}`;
  $('#apiStatus').innerHTML = active
    ? '<i class="fas fa-circle" aria-hidden="true"></i> Active'
    : '<i class="fas fa-circle" aria-hidden="true"></i> Not set';
  for (const id of ['#apiKeyInput', '#settingsApiKey']) {
    $(id).value = '';                                            // never echo the stored key back (NFR-3.2)
    $(id).placeholder = active ? '•••••••• key saved (enter a new one to replace)' : id === '#apiKeyInput' ? 'Enter Gemini API Key…' : 'AIza…';
  }
}

function toggleVisibility(inputSel, btnSel) {
  $(btnSel).addEventListener('click', () => {
    const input = $(inputSel);
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    $(btnSel).querySelector('i').className = `fas ${show ? 'fa-eye-slash' : 'fa-eye'}`;
  });
}

function saveKey(value, modelValue) {
  try {
    if (value) { gemini.setApiKey(value); audit.log('api_key_set'); showToast('API key saved on this device.', 'success'); }
    if (modelValue !== undefined) gemini.setModel(modelValue);
  } catch (e) { showToast(e.message, 'error'); }
}

export function initSettings({ onSaveHistoryOff }) {
  $('#settingsBtn').addEventListener('click', () => { $('#settingsModel').value = gemini.getModel(); openModal('settingsModal'); });
  $('#aboutBtn').addEventListener('click', () => openModal('aboutModal'));
  $('#appVersion').textContent = APP.version;
  $('#settingsModel').placeholder = `Default: ${GEMINI.models[0]}`;

  $('#elderlyToggle').addEventListener('click', () => setPrefs({ elderly: !getPrefs().elderly }));
  $('#settingsElderlyMode').addEventListener('change', (e) => setPrefs({ elderly: e.target.checked }));
  $('#settingsHighContrast').addEventListener('change', (e) => setPrefs({ contrast: e.target.checked }));
  $('#settingsFontSize').addEventListener('change', (e) => setPrefs({ font: e.target.value }));
  $('#settingsSaveHistory').addEventListener('change', (e) => {
    setPrefs({ saveHistory: e.target.checked });
    if (!e.target.checked) { store.remove(KEYS.chat); onSaveHistoryOff?.(); }
  });

  toggleVisibility('#apiKeyInput', '#toggleApiKeyVisibility');
  toggleVisibility('#settingsApiKey', '#toggleSettingsKey');
  $('#setApiKeyBtn').addEventListener('click', () => saveKey($('#apiKeyInput').value));
  $('#apiKeyInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') saveKey($('#apiKeyInput').value); });
  $('#saveSettingsKey').addEventListener('click', () => saveKey($('#settingsApiKey').value, $('#settingsModel').value));

  $('#clearAllDataBtn').addEventListener('click', () => {
    if (!window.confirm('Remove your API key, chat history, profile, accounts and all settings from this device? This cannot be undone.')) return;
    store.clearAll();
    showToast('All local data removed.', 'success');
    setTimeout(() => location.reload(), 600);
  });

  gemini.onKeyChange(renderKeyStatus);
  renderKeyStatus(gemini.hasApiKey());
  applyPrefs();
}
