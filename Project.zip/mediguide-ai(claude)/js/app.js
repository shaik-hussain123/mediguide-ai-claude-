/** @file Entry point: bootstraps modules and owns the search → detail data flow (SRS §6.3). */
import { $, $$, initModals, showToast } from './utils/helpers.js';
import * as db from './data/medicineDB.js';
import { initSearch } from './components/search.js';
import { renderResults, renderMedicine, renderStoreLinks, initDetail, ageGroupFor } from './components/medicineDetail.js';
import { initCompanies, renderCompanies, openCompany } from './components/companyList.js';
import { initChat, setContext, focusChat } from './components/chatBot.js';
import { initAuth, onAuthChange } from './components/auth.js';
import { initSettings } from './components/settings.js';
import { initConsent } from './components/consent.js';
import { initScanners } from './components/scanner.js';
import { initAdmin } from './components/admin.js';

const state = { query: '', category: '', company: '', selectedId: null, age: 'adult' };
let search;

function refresh() {
  const results = db.search(state.query, { category: state.category, company: state.company });
  if (!results.some((m) => m.id === state.selectedId)) state.selectedId = results[0]?.id ?? null;   // data-flow step 2
  const med = db.getById(state.selectedId);
  $('#medDetail').innerHTML = renderResults(results, state.selectedId, state.query) + renderMedicine(med, state.age);
  $('#globalStoreLinks').innerHTML = renderStoreLinks(med, state.query);
  $('#medicineCount').textContent = db.getAll().length;
  renderCompanies(state.company);
  setContext(med || null);
}

function activateTab(pageId) {
  $$('.page-tab').forEach((t) => { const on = t.dataset.page === pageId; t.classList.toggle('active', on); t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1; });
  ['pageMedicine', 'pageScanner', 'pagePrescription'].forEach((id) => { $(`#${id}`).hidden = id !== pageId; });
}

function initTabs() {
  const tabs = $$('.page-tab');
  tabs.forEach((t, i) => {
    t.addEventListener('click', () => activateTab(t.dataset.page));
    t.addEventListener('keydown', (e) => {                                  // arrow-key tab navigation (FR-10.4)
      const d = { ArrowRight: 1, ArrowLeft: -1 }[e.key];
      if (!d) return;
      const next = tabs[(i + d + tabs.length) % tabs.length];
      next.focus(); next.click();
    });
  });
}

function selectMedicine(id) {
  state.selectedId = id;
  const rec = db.getById(id);
  if (rec && !db.search(state.query, { category: state.category, company: state.company }).includes(rec)) {
    Object.assign(state, { query: '', category: '', company: '' });   // selected item is hidden by filters: reset them
    search.reset();
  }
  refresh();
  $('#medDetail').querySelector('.med-card')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

async function boot() {
  initModals();
  initSettings({ onSaveHistoryOff: () => {} });
  initAuth();
  initConsent();
  initChat();
  initScanners();
  initAdmin();
  initTabs();

  $('#dismissBanner').addEventListener('click', () => { $('#disclaimerBanner').hidden = true; });

  search = initSearch({
    onChange: ({ query, category }) => { Object.assign(state, { query, category }); refresh(); },
    onClear: () => { Object.assign(state, { query: '', category: '', company: '' }); refresh(); },
  });
  initCompanies({
    onFilter: (name) => { state.company = name; refresh(); },
    onPick: selectMedicine,
  });
  initDetail($('#medDetail'), {
    onSelect: selectMedicine,
    onCompany: openCompany,
    onAsk: (id) => { const m = db.getById(id); setContext(m); focusChat(`Tell me about ${m.name}`); },
  });
  document.addEventListener('mg:open-medicine', (e) => { activateTab('pageMedicine'); selectMedicine(e.detail); });
  onAuthChange((u) => { state.age = ageGroupFor(u?.profile?.age); if (search) refresh(); });   // default age tab from profile

  search.setCategories(db.categories());
  refresh();                                                                                  // instant first paint from bundled data
  const added = await db.loadExtra();                                                         // optional larger dataset
  if (added) { search.setCategories(db.categories()); refresh(); showToast(`${added} more medicines loaded.`, 'info', 2500); }

  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
    navigator.serviceWorker.register('sw.js').catch(() => { /* offline support is optional */ });   // NFR-6.3
  }
}

boot();
