# MediGuide AI · Smart Medicine Assistant

Elderly-friendly medicine information for India with a multimodal Gemini chatbot.
Vanilla HTML/CSS/JS ES modules. No build step. Implements `MediGuide_AI_SRS_1.docx` (phase 1, frontend-first).

## Run

ES modules do not load from `file://`, so serve the folder:

```
npm start        # http://localhost:5500   (or: python3 -m http.server 5500)
npm test         # dataset, search, prescription parser, TOTP checks
```

Register with `admin@mediguide.in` to become the demo admin (client-side only, not a security boundary), open **Admin → API Key** and paste a free Gemini key from https://aistudio.google.com. Regular users and guests only see "AI ready / not set up".
Admins can also edit each medicine's "Commonly used for" list under **Admin → Medicines**.

## SRS coverage

| SRS | Where | Notes |
|---|---|---|
| FR-1 search | `components/search.js`, `data/medicineDB.js` | ≥2 chars, 300 ms debounce, Enter/button, partial, case-insensitive, name/company/category/**symptom** |
| FR-2/3 detail + dosage visuals | `components/medicineDetail.js` | pill icons, clock/frequency, daily timeline, meal timing, age tabs, colour-coded tier (+icons, not colour alone) |
| FR-4 alternatives | same | table with green pros / red cons |
| FR-5 stores | `config.js` `STORES` | new tab, medicine name in query, verified stores only |
| FR-6 companies | `components/companyList.js` | chips filter, loading/empty states, company page (modal) |
| FR-7 chatbot | `components/chatBot.js`, `services/gemini.js` | text, image, **audio, video**, voice dictation, typing indicator, safe formatting, 50-record history, disclaimer on every reply, clear key errors, 1 auto-retry + model fallback |
| FR-8 auth/profile | `components/auth.js` | PBKDF2-hashed local accounts, login throttle, TOTP hook, profile |
| FR-9 API key | `components/admin.js` (Admin → API Key) | admin-only: masked input, status, model override, remove; never echoed back. Chat shows status only |
| FR-10 accessibility | `settings.js`, `css/` | font sizes, elderly mode, high contrast, ARIA, keyboard nav, focus trap, skip link, glossary tooltips |
| FR-11 responsive | `css/style.css` | 2-col ≥1000 px, stacked below, ≥44 px taps, verified at 320 px |
| NFR-3 security | `index.html` CSP | no inline scripts/handlers, escaped output, file validation, key in header not URL, consent first, Clear all data |
| NFR-6.3 offline | `sw.js`, `manifest.json` | static data offline; installable |
| §9 disclaimers | banner, footer, every AI reply | exact wording from the SRS |
| Extra (in your shell) | `scanner.js`, `admin.js` | image scanner, prescription analyser (offline text parser + Gemini for files), admin stats/users/audit |

## Things you must know

- **The API key is stored per browser.** With no backend, the admin's key lives in the admin's own browser (localStorage), so other users on other devices do not get it. To share one key with everyone, add a small backend proxy that holds the key server-side (SRS §12.3). Never hard-code a key in the front-end files: anyone can read it.
- **Admin edits to "commonly used for" are also per browser** (stored as overrides). For site-wide changes, edit `USES` in `js/data/medicineDB.js` or `data/medicines.json`.
- **Medical data needs professional review.** The 12 medicines, doses and alternatives are a curated starter set written from general reference knowledge. Have a pharmacist verify every entry against CDSCO/label data before real users rely on it. Add more in `data/medicines.json` (same shape; merged automatically; the search is index-based for 1,000+ records, NFR-7.1).
- **Gemini model names change.** `config.js` tries `gemini-3.5-flash`, then fallbacks; users can override the model in Settings. The README previously named 1.5 Flash, which is retired.
- **Store URL patterns** (esp. PlatinumRx) must be verified; sites change routes.
- **Not production auth.** Accounts, roles and the API key live in localStorage. HIPAA/GDPR readiness here means architecture (consent, audit log, local-only data, delete-all), not certification. Real compliance needs the backend (SRS §12.3).
- **Deferred by the SRS:** multi-language, PWA push reminders, ABHA, backend. 2FA enrolment UI needs a backend; verification is implemented.
- Lighthouse scores (SRS §11 items 11–12) were not measured here: run them on your deployment.
