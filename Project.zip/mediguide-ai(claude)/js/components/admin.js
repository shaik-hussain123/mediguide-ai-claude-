/** @file Admin dashboard (FR-20 in the shell): stats, users, audit log. Local data only in phase 1. */
import { $, $$, escapeHtml as h, formatDate, openModal, showToast } from '../utils/helpers.js';
import * as store from '../utils/storage.js';
import * as audit from '../utils/audit.js';
import { allUsers, isAdmin } from './auth.js';
import { getAll, categories, companies } from '../data/medicineDB.js';
import { KEYS } from '../config.js';

const table = (head, rows, empty) => rows.length
  ? `<div class="table-wrap" tabindex="0"><table class="alt-table"><thead><tr>${head.map((x) => `<th scope="col">${x}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
  : `<p class="settings-note">${empty}</p>`;

function render() {
  const meds = getAll();
  const stats = [
    ['fa-pills', meds.length, 'Medicines'], ['fa-building', companies().length, 'Manufacturers'], ['fa-tags', categories().length, 'Categories'],
    ['fa-users', allUsers().length, 'Local accounts'], ['fa-comments', store.get(KEYS.chat, []).length, 'Saved chat records'], ['fa-camera', store.get(KEYS.scans, []).length, 'Scans'],
    ['fa-file-prescription', meds.filter((m) => m.rx).length, 'Rx-only medicines'],
  ];
  $('#adminStatsContent').innerHTML = `<div class="stat-grid">${stats.map(([i, n, l]) => `<div class="stat"><i class="fas ${i}" aria-hidden="true"></i><strong>${n}</strong><span>${l}</span></div>`).join('')}</div>
    <p class="settings-note">Phase 1 reads this browser’s data only. Site-wide analytics need the backend (SRS §12.3).</p>`;
  $('#adminUsersContent').innerHTML = table(['Name', 'Email', 'Role', 'Created'],
    allUsers().map((u) => `<tr><td>${h(u.name)}</td><td>${h(u.email)}</td><td>${h(u.role)}</td><td>${h(formatDate(u.created, false))}</td></tr>`), 'No accounts on this device yet.');
  $('#adminAuditContent').innerHTML = table(['Time', 'Event', 'Detail'],
    audit.all().map((a) => `<tr><td>${h(formatDate(a.t))}</td><td>${h(a.event)}</td><td>${h(a.detail || '—')}</td></tr>`), 'No events yet.');
}

export function initAdmin() {
  $('#adminPanelBtn').addEventListener('click', () => {
    if (!isAdmin()) return showToast('Admin access only.', 'warn');
    render(); openModal('adminModal');
  });
  $$('.admin-tab').forEach((tab) => tab.addEventListener('click', () => {
    $$('.admin-tab').forEach((t) => { t.classList.toggle('active', t === tab); t.setAttribute('aria-selected', String(t === tab)); });
    $$('.admin-panel').forEach((p) => { p.hidden = p.id !== tab.dataset.panel; });
  }));
}
