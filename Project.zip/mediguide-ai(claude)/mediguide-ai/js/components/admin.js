/** @file Admin dashboard (FR-20 in the shell): stats, users, audit log. Local data only in phase 1. */
import { $, $$, escapeHtml as h, formatDate, openModal, showToast } from '../utils/helpers.js';
import * as store from '../utils/storage.js';
import * as audit from '../utils/audit.js';
import { allUsers, isAdmin } from './auth.js';
import { getAll, categories, companies, setUses, resetUses, hasUsesOverride } from '../data/medicineDB.js';
import * as gemini from '../services/gemini.js';
import { KEYS, GEMINI } from '../config.js';

const table = (head, rows, empty) => rows.length
  ? `<div class="table-wrap" tabindex="0"><table class="alt-table"><thead><tr>${head.map((x) => `<th scope="col">${x}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody></table></div>`
  : `<p class="settings-note">${empty}</p>`;

function renderKeyPanel() {
  const active = gemini.hasApiKey();
  $('#adminKeyStatus').className = `api-status${active ? ' active' : ''}`;
  $('#adminKeyStatus').innerHTML = `<i class="fas fa-circle" aria-hidden="true"></i> ${active ? 'Active' : 'Not set'}`;
  $('#adminApiKey').value = '';                                   // never echo the saved key (NFR-3.2)
  $('#adminApiKey').placeholder = active ? '•••••••• saved. Enter a new key to replace it' : 'AIza…';
  $('#adminModel').value = gemini.getModel();
  $('#adminModel').placeholder = `Default: ${GEMINI.models[0]}`;
}

function renderMeds() {
  $('#adminMedsContent').innerHTML = getAll().map((m) => `<div class="uses-row">
    <label for="uses-${m.id}">${h(m.name)} <small>(${h(m.generic || '')})</small></label>
    <input type="text" id="uses-${m.id}" value="${h((m.uses || []).join(', '))}" maxlength="400" placeholder="e.g. Fever, Headache, Body ache" />
    <div class="uses-actions">
      <button type="button" class="btn-primary" data-save-uses="${m.id}"><i class="fas fa-save" aria-hidden="true"></i> Save</button>
      ${hasUsesOverride(m.id) ? `<button type="button" class="btn-secondary" data-reset-uses="${m.id}"><i class="fas fa-rotate-left" aria-hidden="true"></i> Reset to default</button>` : ''}
    </div></div>`).join('');
}

function render() {
  const meds = getAll();
  const stats = [
    ['fa-pills', meds.length, 'Medicines'], ['fa-building', companies().length, 'Manufacturers'], ['fa-tags', categories().length, 'Categories'],
    ['fa-users', allUsers().length, 'Local accounts'], ['fa-comments', store.get(KEYS.chat, []).length, 'Saved chat records'], ['fa-camera', store.get(KEYS.scans, []).length, 'Scans'],
    ['fa-file-prescription', meds.filter((m) => m.rx).length, 'Rx-only medicines'],
  ];
  $('#adminStatsContent').innerHTML = `<div class="stat-grid">${stats.map(([i, n, l]) => `<div class="stat"><i class="fas ${i}" aria-hidden="true"></i><strong>${n}</strong><span>${l}</span></div>`).join('')}</div>
    <p class="settings-note">Phase 1 reads this browser’s data only. Site-wide analytics need the backend (SRS §12.3).</p>`;
  $('#adminUsersContent').innerHTML = table(['Name', 'Email', 'Role', 'Created'],
    allUsers().map((u) => `<tr><td>${h(u.name)}</td><td>${h(u.email)}</td><td>${h(u.role)}</td><td>${h(formatDate(u.created, false))}</td></tr>`), 'No accounts on this device yet.');
  $('#adminAuditContent').innerHTML = table(['Time', 'Event', 'Detail'],
    audit.all().map((a) => `<tr><td>${h(formatDate(a.t))}</td><td>${h(a.event)}</td><td>${h(a.detail || '—')}</td></tr>`), 'No events yet.');
}

export function initAdmin() {
  // Every mutating action re-checks the role. Client-side only: the future backend must enforce it (SRS §8.2).
  const guard = () => { if (isAdmin()) return true; showToast('Admin access only.', 'warn'); return false; };
  const changed = () => document.dispatchEvent(new CustomEvent('mg:data-changed'));

  $('#adminPanelBtn').addEventListener('click', () => {
    if (!guard()) return;
    render(); renderKeyPanel(); renderMeds(); openModal('adminModal');
  });

  $('#adminToggleKey').addEventListener('click', () => {
    const i = $('#adminApiKey'); const show = i.type === 'password';
    i.type = show ? 'text' : 'password';
    $('#adminToggleKey i').className = `fas ${show ? 'fa-eye-slash' : 'fa-eye'}`;
  });
  $('#adminSaveKey').addEventListener('click', () => {
    if (!guard()) return;
    try {
      const key = $('#adminApiKey').value.trim();
      if (key) { gemini.setApiKey(key); audit.log('api_key_set'); }
      const before = gemini.getModel();
      gemini.setModel($('#adminModel').value);
      if (gemini.getModel() !== before) audit.log('model_changed', gemini.getModel() || 'default');
      if (!key && gemini.getModel() === before) return showToast('Nothing to save. Enter a new key or model.', 'info');
      showToast('Saved.', 'success'); renderKeyPanel(); render();
    } catch (e) { showToast(e.message, 'error'); }
  });
  $('#adminRemoveKey').addEventListener('click', () => {
    if (!guard() || !gemini.hasApiKey()) return;
    if (!window.confirm('Remove the API key? Chat and scanning will stop working until a new key is added.')) return;
    gemini.clearApiKey(); audit.log('api_key_removed'); showToast('API key removed.', 'success'); renderKeyPanel();
  });

  $('#adminMedsContent').addEventListener('click', (e) => {
    if (!guard()) return;
    const save = e.target.closest('[data-save-uses]');
    const reset = e.target.closest('[data-reset-uses]');
    if (save) {
      const id = Number(save.dataset.saveUses);
      const list = setUses(id, $(`#uses-${id}`).value.split(','));
      audit.log('uses_edited', `medicine ${id}`);
      showToast(`Saved ${list.length} item${list.length === 1 ? '' : 's'}.`, 'success'); renderMeds(); changed();
    } else if (reset) {
      resetUses(Number(reset.dataset.resetUses)); audit.log('uses_reset', `medicine ${reset.dataset.resetUses}`);
      showToast('Restored the default list.', 'success'); renderMeds(); changed();
    }
  });
  $$('.admin-tab').forEach((tab) => tab.addEventListener('click', () => {
    $$('.admin-tab').forEach((t) => { t.classList.toggle('active', t === tab); t.setAttribute('aria-selected', String(t === tab)); });
    $$('.admin-panel').forEach((p) => { p.hidden = p.id !== tab.dataset.panel; });
  }));
}
