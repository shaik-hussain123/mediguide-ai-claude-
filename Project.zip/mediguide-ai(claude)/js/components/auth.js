/**
 * @file Login / register / profile (FR-8, SRS §8.1–8.2). Phase 1 is a local mock: accounts live in
 * this browser only, passwords are PBKDF2-hashed, and a TOTP hook is ready for 2FA (NFR-3.6).
 * Client-side roles are not a security boundary: the future backend must enforce them.
 */
import { $, $$, escapeHtml as h, formatDate, hashPassword, randomHex, uid, showToast, openModal, closeModal } from '../utils/helpers.js';
import { verifyTotp } from '../utils/totp.js';
import * as store from '../utils/storage.js';
import * as audit from '../utils/audit.js';
import { KEYS, ADMIN_EMAILS } from '../config.js';

const listeners = new Set();
export const onAuthChange = (fn) => { listeners.add(fn); fn(currentUser()); };
const emit = () => listeners.forEach((fn) => fn(currentUser()));

const users = () => store.get(KEYS.users, []);
const saveUsers = (list) => store.set(KEYS.users, list);

export function currentUser() {
  const s = store.get(KEYS.session, null);
  return s ? users().find((u) => u.id === s.userId) || null : null;
}
export const loginTime = () => store.get(KEYS.session, null)?.loginAt || null;
export const isAdmin = (u = currentUser()) => u?.role === 'admin';
export const allUsers = () => users().map(({ id, name, email, role, created }) => ({ id, name, email, role, created }));

const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/;
const fails = new Map();            // basic brute-force throttle per email (in memory)
function throttled(email) {
  const f = fails.get(email);
  return f && f.count >= 5 && Date.now() - f.last < 60000;
}

export async function register({ name, email, password, consent }) {
  name = String(name || '').trim().slice(0, 80);
  email = String(email || '').trim().toLowerCase();
  if (name.length < 2) throw new Error('Please enter your full name.');
  if (!EMAIL_RE.test(email)) throw new Error('Please enter a valid email address.');
  if (String(password || '').length < 8) throw new Error('Password must be at least 8 characters.');
  if (!consent) throw new Error('Please tick the box to confirm you understand this is informational only.');
  if (users().some((u) => u.email === email)) throw new Error('An account with this email already exists. Please log in.');
  const salt = randomHex(16);
  const user = {
    id: uid(), name, email, salt, hash: await hashPassword(password, salt),
    role: ADMIN_EMAILS.includes(email) ? 'admin' : 'user', created: new Date().toISOString(),
    totpSecret: null, profile: { age: '', weight: '', conditions: '', allergies: '' },
  };
  saveUsers([...users(), user]);
  store.set(KEYS.session, { userId: user.id, loginAt: new Date().toISOString() });
  audit.log('register', user.role);
  emit();
  return user;
}

export async function login({ email, password, totp }) {
  email = String(email || '').trim().toLowerCase();
  if (throttled(email)) throw new Error('Too many attempts. Please wait a minute and try again.');
  const user = users().find((u) => u.email === email);
  const ok = user && (await hashPassword(String(password || ''), user.salt)) === user.hash;
  if (!ok) {
    const f = fails.get(email) || { count: 0 };
    fails.set(email, { count: f.count + 1, last: Date.now() });
    audit.log('login_failed');
    throw new Error('Email or password is incorrect.');
  }
  if (user.totpSecret && !(await verifyTotp(user.totpSecret, String(totp || '').trim()))) {
    audit.log('login_2fa_failed');
    throw new Error('Enter the 6-digit code from your authenticator app.');
  }
  fails.delete(email);
  store.set(KEYS.session, { userId: user.id, loginAt: new Date().toISOString() });
  audit.log('login');
  emit();
  return user;
}

export function logout() {
  audit.log('logout');
  store.remove(KEYS.session);
  emit();
}

export function updateProfile(patch) {
  const u = currentUser();
  if (!u) throw new Error('Please log in first.');
  const age = patch.age === '' ? '' : Number(patch.age);
  const weight = patch.weight === '' ? '' : Number(patch.weight);
  if (age !== '' && !(age >= 1 && age <= 120)) throw new Error('Age must be between 1 and 120.');
  if (weight !== '' && !(weight >= 1 && weight <= 300)) throw new Error('Weight must be between 1 and 300 kg.');
  const profile = { age, weight, conditions: String(patch.conditions || '').trim().slice(0, 200), allergies: String(patch.allergies || '').trim().slice(0, 200) };
  saveUsers(users().map((x) => (x.id === u.id ? { ...x, profile } : x)));
  audit.log('profile_updated');
  emit();
}

/* ------------------------------ UI wiring ------------------------------ */
function switchAuthTab(which) {
  ['Login', 'Register'].forEach((n) => {
    const active = n === which;
    $(`#tab${n}`).classList.toggle('active', active);
    $(`#tab${n}`).setAttribute('aria-selected', String(active));
    $(`#panel${n}`).hidden = !active;
  });
}

function setBusy(btn, busy, label) {
  btn.disabled = busy;
  if (label) btn.dataset.label = btn.dataset.label || btn.innerHTML;
  btn.innerHTML = busy ? '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Please wait…' : btn.dataset.label || btn.innerHTML;
}

function renderSession(u) {
  const first = u ? u.name.split(' ')[0] : '';
  $('#loginBtn').hidden = Boolean(u);
  $('#profileBtn').hidden = !u;
  $('#profileBtn').style.display = u ? '' : 'none';
  $('#profileBtnLabel').textContent = first || 'Profile';
  $('#sessionUser').innerHTML = `<i class="fas fa-user-circle" aria-hidden="true"></i> ${u ? h(u.name) : 'Guest'}`;
  $('#lastLogin').textContent = u ? formatDate(loginTime()) : '—';
  $('#adminPanelBtn').hidden = !isAdmin(u);
}

function fillProfile() {
  const u = currentUser();
  if (!u) return;
  $('#profileName').textContent = u.name;
  $('#profileEmail').textContent = u.email;
  $('#profileAvatar').textContent = u.name.trim()[0].toUpperCase();
  $('#profileAge').value = u.profile.age;
  $('#profileWeight').value = u.profile.weight;
  $('#profileConditions').value = u.profile.conditions;
  $('#profileAllergies').value = u.profile.allergies;
  $('#profileLoginTime').textContent = formatDate(loginTime());
  $('#profileChatCount').textContent = store.get(KEYS.chat, []).length * 2;
}

export function initAuth() {
  $('#loginBtn').addEventListener('click', () => { switchAuthTab('Login'); openModal('loginModal'); });
  $('#profileBtn').addEventListener('click', () => { fillProfile(); openModal('profileModal'); });
  $('#tabLogin').addEventListener('click', () => switchAuthTab('Login'));
  $('#tabRegister').addEventListener('click', () => switchAuthTab('Register'));

  const submitOnEnter = (panel, btn) => $(panel).addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $(btn).click(); } });
  submitOnEnter('#panelLogin', '#doLoginBtn');
  submitOnEnter('#panelRegister', '#doRegisterBtn');

  $('#doLoginBtn').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    setBusy(btn, true, true);
    try {
      const u = await login({ email: $('#loginEmail').value, password: $('#loginPassword').value, totp: $('#loginTOTP').value });
      $('#loginPassword').value = ''; $('#loginTOTP').value = '';
      closeModal('loginModal');
      showToast(`Welcome back, ${u.name.split(' ')[0]}.`, 'success');
    } catch (err) { showToast(err.message, 'error'); } finally { setBusy(btn, false); }
  });

  $('#doRegisterBtn').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    setBusy(btn, true, true);
    try {
      const u = await register({ name: $('#regName').value, email: $('#regEmail').value, password: $('#regPassword').value, consent: $('#consentCheck').checked });
      $('#regPassword').value = '';
      closeModal('loginModal');
      showToast(`Account created. Welcome, ${u.name.split(' ')[0]}.`, 'success');
    } catch (err) { showToast(err.message, 'error'); } finally { setBusy(btn, false); }
  });

  $('#saveProfileBtn').addEventListener('click', () => {
    try {
      updateProfile({ age: $('#profileAge').value, weight: $('#profileWeight').value, conditions: $('#profileConditions').value, allergies: $('#profileAllergies').value });
      showToast('Profile saved on this device.', 'success');
    } catch (err) { showToast(err.message, 'error'); }
  });
  $('#logoutBtn').addEventListener('click', () => { logout(); closeModal('profileModal'); showToast('You have been logged out.', 'info'); });

  onAuthChange(renderSession);
}
