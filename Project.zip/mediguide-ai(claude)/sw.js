/* Offline support for static data (NFR-6.3). Never caches API calls: Gemini requests are cross-origin POSTs and are ignored. */
const CACHE = 'mediguide-v1';
const SHELL = ['./', 'index.html', 'manifest.json', 'icons/icon.svg', 'css/style.css', 'css/components.css', 'css/modals.css',
  'js/app.js', 'js/config.js', 'js/data/medicineDB.js', 'js/services/gemini.js', 'js/utils/helpers.js', 'js/utils/storage.js', 'js/utils/audit.js',
  'js/utils/totp.js', 'js/utils/rxParser.js', 'js/components/auth.js', 'js/components/chatBot.js', 'js/components/companyList.js', 'js/components/consent.js',
  'js/components/medicineDetail.js', 'js/components/search.js', 'js/components/settings.js', 'js/components/scanner.js', 'js/components/admin.js'];
const CDN = ['cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com'];

self.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === location.origin;
  if (!sameOrigin && !CDN.includes(url.hostname)) return;
  // network-first for our own files (fresh when online), stale-while-revalidate for CDN icons/fonts
  e.respondWith(
    sameOrigin
      ? fetch(req).then((res) => { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); return res; }).catch(() => caches.match(req).then((r) => r || caches.match('index.html')))
      : caches.match(req).then((hit) => {
        const net = fetch(req).then((res) => { caches.open(CACHE).then((c) => c.put(req, res.clone())); return res; }).catch(() => hit);
        return hit || net;
      }),
  );
});
